#!/usr/bin/python
#coding:utf-8
#@Author:醉清风
#求47模30的逆为23

import gmpy2

print gmpy2.invert(47,30)

