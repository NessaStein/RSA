(1)已知明文的前440位，后72位未知，用coppersmith算法得出完整的m：
(2)已知n,不知道p的后128位，仍然用coppersmith算法求出q：(exp.py)
(3)已知d的后512位，还是用coppersmith算法求出q：
已知两个素数p、q中只给出了一个，并且另一个后面还有好多0，看来是一个不完整的数。使用Coppersmith定理复原
